#!/bin/bash

echo Hello Kitty $1 >> first_run.txt &


